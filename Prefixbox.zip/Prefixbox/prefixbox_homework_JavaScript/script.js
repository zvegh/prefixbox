const checkbox = document.getElementsByClassName('sale')[0]
const productsOnSale = document.getElementsByClassName('product-old-price')
const products = document.querySelectorAll('.product')

console.log(products)

function check() {
    checkbox.checked = true
}

function uncheck() {
    checkbox.checked = false
}

checkbox.addEventListener('change', () => {
   
    if(checkbox.checked == true) {
        check()
        for(let i = 0; i < products.length; i++) {
            if(!products[i].classList.contains('show')) {
                
                products[i].style.display = 'none'
            }
        }
    } else {
        uncheck()
        for(let i = 0; i < products.length; i++) {
            if(!products[i].classList.contains('show')) {
                
                products[i].style.display = 'inline-block'
            }
        }
    }
    
})

for(let i = 0; i < productsOnSale.length; i++) {
    var element = productsOnSale[i].parentNode.parentNode.classList.add('show')
}

// Sort by Alphabetical order
// by giving the divs ids

for(let i = 0; i < products.length; i++) {
   const productData =  products[i].childNodes[3]
   const productName = productData.childNodes[1]
   console.log(productName.innerHTML)
   
   products[i].id = productName.innerHTML
}


console.log(products)





